<?php
// IndoGulf Yoga Hub - Configuration
// Update these with your Hostinger database details

// Database Configuration (from Hostinger cPanel)
define('DB_HOST', 'localhost');           // Usually localhost on Hostinger
define('DB_USER', 'u1234567_yoga');       // Your Hostinger database username
define('DB_PASS', 'your_password_here');  // Your database password
define('DB_NAME', 'indogulf_hub');        // Your database name

// Site Configuration
define('SITE_NAME', 'IndoGulf Yoga Hub');
define('SITE_URL', 'https://yourdomain.com'); // Your domain on Hostinger
define('UPLOAD_DIR', __DIR__ . '/uploads/');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8");

// Session configuration
session_start();
if (empty($_SESSION['session_start'])) {
    $_SESSION['session_start'] = time();
}

// Helper function to check if admin is logged in
function check_admin_login() {
    if (!isset($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit();
    }
}

// Helper function to escape output
function escape_output($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// Helper function to generate invoice number
function generate_invoice_number($conn) {
    $date = date('Ymd');
    $result = $conn->query("SELECT MAX(id) as max_id FROM invoices WHERE DATE(created_at) = CURDATE()");
    $row = $result->fetch_assoc();
    $counter = ($row['max_id'] ? $row['max_id'] + 1 : 1);
    return 'INV-' . $date . '-' . str_pad($counter, 4, '0', STR_PAD_LEFT);
}

// Error logging
function log_error($message) {
    $log_file = __DIR__ . '/logs/error.log';
    if (!is_dir(__DIR__ . '/logs')) {
        mkdir(__DIR__ . '/logs', 0755, true);
    }
    file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

?>
