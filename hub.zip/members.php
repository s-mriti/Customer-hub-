<?php
require_once 'config.php';
check_admin_login();

$action = $_GET['action'] ?? '';
$member_id = $_GET['id'] ?? '';
$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $first_name = $_POST['first_name'] ?? '';
        $last_name = $_POST['last_name'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $membership_type = $_POST['membership_type'] ?? '';
        $join_date = $_POST['join_date'] ?? date('Y-m-d');
        $status = $_POST['status'] ?? 'active';
        $notes = $_POST['notes'] ?? '';
        
        if ($first_name && $last_name) {
            $stmt = $conn->prepare("
                INSERT INTO members (first_name, last_name, email, phone, membership_type, join_date, status, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssssssss", $first_name, $last_name, $email, $phone, $membership_type, $join_date, $status, $notes);
            
            if ($stmt->execute()) {
                $new_member_id = $conn->insert_id;
                
                // Add custom fields if provided
                foreach ($_POST as $key => $value) {
                    if (strpos($key, 'custom_field_') === 0 && $value) {
                        $field_name = str_replace('custom_field_', '', $key);
                        $field_value = $value;
                        $custom_stmt = $conn->prepare("INSERT INTO member_custom_fields (member_id, field_name, field_value) VALUES (?, ?, ?)");
                        $custom_stmt->bind_param("iss", $new_member_id, $field_name, $field_value);
                        $custom_stmt->execute();
                    }
                }
                
                $message = "Member added successfully!";
                $action = '';
            }
        } else {
            $message = "First name and last name are required";
        }
    } elseif ($action === 'edit' && $member_id) {
        $first_name = $_POST['first_name'] ?? '';
        $last_name = $_POST['last_name'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $membership_type = $_POST['membership_type'] ?? '';
        $status = $_POST['status'] ?? 'active';
        $notes = $_POST['notes'] ?? '';
        
        $stmt = $conn->prepare("
            UPDATE members 
            SET first_name=?, last_name=?, email=?, phone=?, membership_type=?, status=?, notes=?
            WHERE id=?
        ");
        $stmt->bind_param("sssssssi", $first_name, $last_name, $email, $phone, $membership_type, $status, $notes, $member_id);
        
        if ($stmt->execute()) {
            $message = "Member updated successfully!";
            $action = '';
        }
    } elseif ($action === 'delete' && $member_id) {
        $stmt = $conn->prepare("DELETE FROM members WHERE id=?");
        $stmt->bind_param("i", $member_id);
        
        if ($stmt->execute()) {
            $message = "Member deleted successfully!";
            header('Location: members.php');
            exit();
        }
    }
}

// Get member for editing
$edit_member = null;
if ($action === 'edit' && $member_id) {
    $result = $conn->query("SELECT * FROM members WHERE id=$member_id");
    $edit_member = $result->fetch_assoc();
    
    // Get custom fields
    $custom_fields = $conn->query("SELECT * FROM member_custom_fields WHERE member_id=$member_id")->fetch_all(MYSQLI_ASSOC);
}

// Get all members
$members = $conn->query("SELECT * FROM members ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members - IndoGulf Yoga Hub</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background-color: #764ba2;
        }
        
        .btn-delete {
            background-color: #ef4444;
        }
        
        .btn-delete:hover {
            background-color: #dc2626;
        }
        
        .message {
            background-color: #d1fae5;
            color: #065f46;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #a7f3d0;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section h2 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="phone"],
        input[type="date"],
        select,
        textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.1);
        }
        
        .form-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        th {
            background-color: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .action-buttons a,
        .action-buttons form {
            margin: 0;
        }
        
        .action-buttons button {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge.active {
            background-color: #d1fae5;
            color: #065f46;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Members Management</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <!-- Add/Edit Member Form -->
        <?php if ($action === 'add' || $action === 'edit'): ?>
        <div class="form-section">
            <h2><?php echo $action === 'add' ? 'Add New Member' : 'Edit Member'; ?></h2>
            <form method="POST">
                <input type="hidden" name="action" value="<?php echo $action; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" value="<?php echo $edit_member['first_name'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" value="<?php echo $edit_member['last_name'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo $edit_member['email'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" value="<?php echo $edit_member['phone'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Membership Type</label>
                        <select name="membership_type">
                            <option value="">Select Type</option>
                            <option value="Monthly" <?php echo ($edit_member['membership_type'] ?? '') === 'Monthly' ? 'selected' : ''; ?>>Monthly</option>
                            <option value="Quarterly" <?php echo ($edit_member['membership_type'] ?? '') === 'Quarterly' ? 'selected' : ''; ?>>Quarterly</option>
                            <option value="Annual" <?php echo ($edit_member['membership_type'] ?? '') === 'Annual' ? 'selected' : ''; ?>>Annual</option>
                            <option value="Pay-per-class" <?php echo ($edit_member['membership_type'] ?? '') === 'Pay-per-class' ? 'selected' : ''; ?>>Pay-per-class</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Join Date</label>
                        <input type="date" name="join_date" value="<?php echo $edit_member['join_date'] ?? date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="active" <?php echo ($edit_member['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo ($edit_member['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="suspended" <?php echo ($edit_member['status'] ?? '') === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Notes</label>
                    <textarea name="notes"><?php echo $edit_member['notes'] ?? ''; ?></textarea>
                </div>
                
                <!-- Custom Fields -->
                <?php if ($action === 'edit' && !empty($custom_fields)): ?>
                    <h3 style="margin-top: 20px; margin-bottom: 15px;">Custom Fields</h3>
                    <?php foreach ($custom_fields as $field): ?>
                        <div class="form-group">
                            <label><?php echo escape_output($field['field_name']); ?></label>
                            <input type="text" name="custom_field_<?php echo escape_output($field['field_name']); ?>" value="<?php echo escape_output($field['field_value']); ?>">
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                
                <div class="form-buttons">
                    <button type="submit" class="btn">Save Member</button>
                    <a href="members.php" class="btn" style="background-color: #999;">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Members List -->
        <div class="form-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>All Members</h2>
                <a href="members.php?action=add" class="btn">+ Add Member</a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Membership</th>
                        <th>Join Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $member): ?>
                        <tr>
                            <td><?php echo escape_output($member['first_name'] . ' ' . $member['last_name']); ?></td>
                            <td><?php echo escape_output($member['email'] ?? 'N/A'); ?></td>
                            <td><?php echo escape_output($member['phone'] ?? 'N/A'); ?></td>
                            <td><?php echo escape_output($member['membership_type'] ?? 'N/A'); ?></td>
                            <td><?php echo $member['join_date'] ? date('M d, Y', strtotime($member['join_date'])) : 'N/A'; ?></td>
                            <td>
                                <span class="badge <?php echo $member['status'] === 'active' ? 'active' : ''; ?>">
                                    <?php echo escape_output(ucfirst($member['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="members.php?action=edit&id=<?php echo $member['id']; ?>" class="btn" style="padding: 5px 10px; font-size: 12px;">Edit</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this member?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $member['id']; ?>">
                                        <button type="submit" class="btn btn-delete" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
