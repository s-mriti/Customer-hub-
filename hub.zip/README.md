# IndoGulf Yoga Hub - Complete Setup Guide

A comprehensive PHP-based customer management platform for yoga studios and wellness businesses. Includes attendance tracking, billing/invoicing, class scheduling, and member management.

## Features

✅ **Member Management** - Add, edit, delete customer profiles with custom fields
✅ **Class Scheduling** - Create and manage yoga/fitness classes with instructors and capacity
✅ **Attendance Tracking** - Real-time check-in/check-out and attendance records
✅ **Billing & Invoicing** - Create invoices, track payments, generate reports
✅ **Admin Dashboard** - Statistics, quick actions, recent activity
✅ **Easy to Maintain** - Simple code structure, easy to customize

---

## Installation on Hostinger

### Step 1: Get Your Database Credentials

1. Log in to your Hostinger cPanel
2. Go to **MySQL Databases** or **phpMyAdmin**
3. Create a new database (e.g., `indogulf_hub`)
4. Write down:
   - **Database Name** (e.g., `u1234567_indogulf`)
   - **Database User** (e.g., `u1234567_yoga`)
   - **Database Password** (generate a secure one)

### Step 2: Upload Files to Hostinger

1. Download all files from this project
2. Log in to Hostinger **File Manager** or use **FTP/SFTP** (better option)
3. Upload all `.php` files to your public_html folder or subdomain folder:
   - `login.php`
   - `dashboard.php`
   - `members.php`
   - `classes.php`
   - `attendance.php`
   - `billing.php`
   - `logout.php`
   - `config.php`

### Step 3: Create the Database

1. Open **phpMyAdmin** in your Hostinger cPanel
2. Select your database
3. Go to **SQL** tab
4. Copy and paste the entire content of `database.sql`
5. Click **Go** to execute

### Step 4: Configure Database Connection

1. Edit `config.php` and update these lines:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_database_user_here');  // From Step 1
define('DB_PASS', 'your_password_here');       // From Step 1
define('DB_NAME', 'your_database_name_here');  // From Step 1
```

2. Upload the updated `config.php`

### Step 5: Access Your Platform

1. Visit: `https://yourdomain.com/login.php` (or your subdomain)
2. **Default Login:**
   - Username: `admin`
   - Password: `admin123`
3. ⚠️ **IMPORTANT:** Change this password immediately after first login

---

## How to Use

### Dashboard
- See quick stats (total members, active classes, pending invoices)
- View recent attendance and members
- Quick access to all modules

### Members
- **Add Members:** Click "Add Member" and fill the form
- **Edit Members:** Click Edit next to member name
- **Custom Fields:** Add extra fields (emergency contact, medical notes, etc.)
- **View All:** See all members with their status

### Classes
- **Add Classes:** Create yoga/fitness classes
- **Set Schedule:** Choose day and time
- **Capacity:** Set max number of participants
- **Types:** Yoga, Aquatics, Fitness, Pilates, Dance

### Attendance
- **Quick Check-in:** Select member → select class → check in
- **View Records:** Filter by date and class
- **Status:** Mark as present, absent, or late
- **Export:** View and print attendance reports

### Billing
- **Create Invoice:** Select member → add line items → set amount
- **Track Payments:** Record payments received
- **Status:** Draft, Sent, Paid, Overdue, Cancelled
- **Reports:** See which members owe money

---

## Important Notes

### File Structure
```
your-domain.com/
├── login.php           (Login page)
├── dashboard.php       (Admin hub)
├── members.php         (Member CRUD)
├── classes.php         (Class management)
├── attendance.php      (Attendance tracking)
├── billing.php         (Invoice management)
├── logout.php          (Session logout)
├── config.php          (Database config - KEEP SECURE!)
├── database.sql        (Database schema)
└── README.md           (This file)
```

### Security Tips
1. ✅ Change default admin password immediately
2. ✅ Keep `config.php` secure (never share it)
3. ✅ Use HTTPS (Hostinger provides free SSL)
4. ✅ Backup your database regularly
5. ✅ Keep database credentials private

### Backup Your Data
1. Weekly: Use phpMyAdmin to export/backup your database
2. Export as SQL file and save locally
3. Also backup your files via File Manager

### Database Maintenance
- Check your Hostinger control panel for database size
- Delete old invoices/attendance records if needed
- Run backups before making changes

---

## Common Issues & Solutions

### "Connection failed" Error
- ❌ Check database credentials in `config.php`
- ❌ Verify database exists in phpMyAdmin
- ✅ Ask Hostinger support to verify MySQL is running

### Login Not Working
- Clear your browser cookies/cache
- Verify database.sql was properly imported
- Check that admin table exists in phpMyAdmin

### Slow Loading
- Check Hostinger's database limits
- Delete old attendance/invoice records
- Contact Hostinger support if persistent

### Can't Upload Files
- Use FTP/SFTP instead of File Manager (faster)
- Ensure you're uploading to correct folder
- Check file permissions (should be 644 for .php files)

---

## Customization

### Add More Custom Fields to Members
1. Open `members.php`
2. Find the form section
3. Duplicate this code:
```html
<div class="form-group">
    <label>Your Custom Field</label>
    <input type="text" name="custom_field_your_field" value="">
</div>
```

### Change Logo/Branding
1. Edit header colors in CSS sections of `.php` files
2. Change "IndoGulf Yoga Hub" text
3. Update company name in `config.php` SITE_NAME

### Add New Invoice Types
1. Open `billing.php`
2. Find the select dropdown for "membership types"
3. Add new options

---

## Support & Updates

### Need Help?
- Check this README first
- Review code comments (PHP is well-documented)
- Ask your developer/IT support

### Future Improvements
- Email notifications when invoices are sent
- SMS reminders for classes
- Mobile app integration
- Multi-admin support
- Advanced reporting

---

## License & Credits

Built for IndoGulf Yoga & Wellness
Designed for easy maintenance and scalability

---

## Quick Reference

| Module | Purpose | Key Actions |
|--------|---------|-------------|
| **Members** | Customer profiles | Add, Edit, Delete, Search |
| **Classes** | Schedule management | Create, Update, Assign instructor |
| **Attendance** | Track participation | Check-in, Generate reports |
| **Billing** | Invoice & payments | Create, Track, Record payment |
| **Dashboard** | Quick overview | Stats, recent activity |

---

## Emergency Contacts

- **Hostinger Support:** cpanel@yourdomain.com
- **Database Issues:** Check phpMyAdmin > SQL tab
- **PHP Errors:** Check Hostinger error logs (cPanel > Error Log)

Good luck! 🎉
