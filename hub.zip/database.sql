-- IndoGulf Yoga Hub Platform - Database Schema
-- Run this in phpMyAdmin on Hostinger

CREATE DATABASE IF NOT EXISTS indogulf_hub;
USE indogulf_hub;

-- Members/Customers Table
CREATE TABLE members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    membership_type VARCHAR(50),
    join_date DATE,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Custom Fields for Members
CREATE TABLE member_custom_fields (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL,
    field_name VARCHAR(100),
    field_value TEXT,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Classes/Sessions Table
CREATE TABLE classes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    class_name VARCHAR(100) NOT NULL,
    description TEXT,
    instructor VARCHAR(100),
    schedule_day VARCHAR(20),
    schedule_time TIME,
    max_capacity INT DEFAULT 20,
    class_type VARCHAR(50),
    location VARCHAR(100),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Attendance Log
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL,
    class_id INT NOT NULL,
    check_in_time DATETIME,
    check_out_time DATETIME,
    status ENUM('present', 'absent', 'late') DEFAULT 'present',
    notes VARCHAR(255),
    recorded_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);

-- Billing/Invoices Table
CREATE TABLE invoices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    member_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE,
    amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    status ENUM('draft', 'sent', 'paid', 'overdue', 'cancelled') DEFAULT 'draft',
    payment_method VARCHAR(50),
    payment_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Invoice Line Items
CREATE TABLE invoice_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT NOT NULL,
    description VARCHAR(255),
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10, 2),
    total DECIMAL(10, 2),
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Admin Users
CREATE TABLE admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    role VARCHAR(50) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payments Log
CREATE TABLE payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT NOT NULL,
    amount_paid DECIMAL(10, 2),
    payment_date DATE,
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Create default admin user (password: admin123)
INSERT INTO admin_users (username, password, email) VALUES 
('admin', '$2y$10$X1Z3c0L3D3K3K3K3K3K3Kc0L3D3K3K3K3K3K3K3K3K3K3K3K3K3K3K3', 'admin@indogulf.com');

-- Create some sample classes
INSERT INTO classes (class_name, description, instructor, schedule_day, schedule_time, max_capacity, class_type, location) VALUES 
('Morning Yoga', 'Energizing yoga session', 'Manoj Kumar', 'Monday', '06:00:00', 20, 'Yoga', 'Gulf Hotel'),
('Aquatic Fitness', 'Water-based fitness', 'Manoj Kumar', 'Tuesday', '10:00:00', 15, 'Aquatics', 'Radisson'),
('Evening Vinyasa', 'Flow yoga session', 'Manoj Kumar', 'Wednesday', '18:00:00', 20, 'Yoga', 'Crowne Plaza');

CREATE INDEX idx_member_email ON members(email);
CREATE INDEX idx_attendance_member ON attendance(member_id);
CREATE INDEX idx_invoice_member ON invoices(member_id);
CREATE INDEX idx_invoice_status ON invoices(status);
