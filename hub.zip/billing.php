<?php
require_once 'config.php';
check_admin_login();

$action = $_GET['action'] ?? '';
$invoice_id = $_GET['id'] ?? '';
$message = '';

// Handle invoice operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $member_id = $_POST['member_id'] ?? '';
        $issue_date = $_POST['issue_date'] ?? date('Y-m-d');
        $due_date = $_POST['due_date'] ?? '';
        $description = $_POST['description'] ?? '';
        $status = $_POST['status'] ?? 'draft';
        $invoice_number = generate_invoice_number($conn);
        
        if ($member_id) {
            $stmt = $conn->prepare("
                INSERT INTO invoices (invoice_number, member_id, issue_date, due_date, description, status, amount)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $total_amount = 0;
            // Calculate total from line items
            if (isset($_POST['line_items'])) {
                foreach ($_POST['line_items'] as $item) {
                    if ($item['description'] && $item['quantity'] && $item['unit_price']) {
                        $total_amount += $item['quantity'] * $item['unit_price'];
                    }
                }
            }
            
            $stmt->bind_param("sisssd", $invoice_number, $member_id, $issue_date, $due_date, $description, $status, $total_amount);
            
            if ($stmt->execute()) {
                $new_invoice_id = $conn->insert_id;
                
                // Add line items
                if (isset($_POST['line_items'])) {
                    foreach ($_POST['line_items'] as $item) {
                        if ($item['description'] && $item['quantity'] && $item['unit_price']) {
                            $item_total = $item['quantity'] * $item['unit_price'];
                            $line_stmt = $conn->prepare("
                                INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, total)
                                VALUES (?, ?, ?, ?, ?)
                            ");
                            $line_stmt->bind_param("isiii", $new_invoice_id, $item['description'], $item['quantity'], $item['unit_price'], $item_total);
                            $line_stmt->execute();
                        }
                    }
                }
                
                $message = "Invoice created successfully! Invoice: " . $invoice_number;
                $action = '';
            }
        } else {
            $message = "Please select a member";
        }
    } elseif ($action === 'edit' && $invoice_id) {
        $status = $_POST['status'] ?? 'draft';
        $due_date = $_POST['due_date'] ?? '';
        $description = $_POST['description'] ?? '';
        
        $stmt = $conn->prepare("UPDATE invoices SET status=?, due_date=?, description=? WHERE id=?");
        $stmt->bind_param("sssi", $status, $due_date, $description, $invoice_id);
        
        if ($stmt->execute()) {
            $message = "Invoice updated successfully!";
        }
    } elseif ($action === 'payment' && $invoice_id) {
        $amount_paid = $_POST['amount_paid'] ?? '';
        $payment_date = $_POST['payment_date'] ?? date('Y-m-d');
        $payment_method = $_POST['payment_method'] ?? '';
        
        if ($amount_paid) {
            // Add payment
            $stmt = $conn->prepare("
                INSERT INTO payments (invoice_id, amount_paid, payment_date, payment_method)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("idss", $invoice_id, $amount_paid, $payment_date, $payment_method);
            
            if ($stmt->execute()) {
                // Update invoice status to paid if fully paid
                $invoice = $conn->query("SELECT amount FROM invoices WHERE id=$invoice_id")->fetch_assoc();
                $total_paid = $conn->query("SELECT SUM(amount_paid) as total FROM payments WHERE invoice_id=$invoice_id")->fetch_assoc()['total'];
                
                if ($total_paid >= $invoice['amount']) {
                    $conn->query("UPDATE invoices SET status='paid', payment_date='$payment_date' WHERE id=$invoice_id");
                }
                
                $message = "Payment recorded successfully!";
            }
        }
    } elseif ($action === 'delete' && $invoice_id) {
        // Delete payments first
        $conn->query("DELETE FROM payments WHERE invoice_id=$invoice_id");
        // Delete line items
        $conn->query("DELETE FROM invoice_items WHERE invoice_id=$invoice_id");
        // Delete invoice
        $stmt = $conn->prepare("DELETE FROM invoices WHERE id=?");
        $stmt->bind_param("i", $invoice_id);
        
        if ($stmt->execute()) {
            $message = "Invoice deleted successfully!";
            header('Location: billing.php');
            exit();
        }
    }
}

// Get invoices for display
$invoices = $conn->query("
    SELECT i.*, m.first_name, m.last_name, m.email 
    FROM invoices i
    JOIN members m ON i.member_id = m.id
    ORDER BY i.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

// Get members for dropdown
$members = $conn->query("SELECT id, first_name, last_name FROM members WHERE status='active' ORDER BY first_name")->fetch_all(MYSQLI_ASSOC);

// Get invoice for editing
$edit_invoice = null;
$invoice_items = [];
$invoice_payments = [];
if ($action === 'edit' && $invoice_id) {
    $result = $conn->query("SELECT * FROM invoices WHERE id=$invoice_id");
    $edit_invoice = $result->fetch_assoc();
    
    $invoice_items = $conn->query("SELECT * FROM invoice_items WHERE invoice_id=$invoice_id")->fetch_all(MYSQLI_ASSOC);
    $invoice_payments = $conn->query("SELECT * FROM payments WHERE invoice_id=$invoice_id")->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing - IndoGulf Yoga Hub</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background-color: #764ba2;
        }
        
        .btn-delete {
            background-color: #ef4444;
        }
        
        .btn-delete:hover {
            background-color: #dc2626;
        }
        
        .message {
            background-color: #d1fae5;
            color: #065f46;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #a7f3d0;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section h2 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="number"],
        input[type="date"],
        select,
        textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
        }
        
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.1);
        }
        
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        th {
            background-color: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge.draft {
            background-color: #e0e7ff;
            color: #3730a3;
        }
        
        .badge.sent {
            background-color: #fef3c7;
            color: #92400e;
        }
        
        .badge.paid {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .badge.overdue {
            background-color: #fee2e2;
            color: #991b1b;
        }
        
        .line-items {
            border-top: 2px solid #e0e0e0;
            margin-top: 20px;
            padding-top: 20px;
        }
        
        .line-item {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .line-item input {
            padding: 8px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Billing & Invoicing</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <!-- Create Invoice Form -->
        <?php if ($action === 'add'): ?>
        <div class="form-section">
            <h2>Create New Invoice</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Member *</label>
                        <select name="member_id" required>
                            <option value="">Select a member...</option>
                            <?php foreach ($members as $member): ?>
                                <option value="<?php echo $member['id']; ?>">
                                    <?php echo escape_output($member['first_name'] . ' ' . $member['last_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Issue Date</label>
                        <input type="date" name="issue_date" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Due Date</label>
                        <input type="date" name="due_date">
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="draft">Draft</option>
                            <option value="sent">Sent</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" placeholder="Invoice description or notes..."></textarea>
                </div>
                
                <!-- Line Items -->
                <div class="line-items">
                    <h3 style="margin-bottom: 15px;">Line Items</h3>
                    <div class="line-item">
                        <strong>Description</strong>
                        <strong>Quantity</strong>
                        <strong>Unit Price</strong>
                        <strong>Total</strong>
                    </div>
                    
                    <?php for ($i = 0; $i < 3; $i++): ?>
                        <div class="line-item">
                            <input type="text" name="line_items[<?php echo $i; ?>][description]" placeholder="Item description">
                            <input type="number" name="line_items[<?php echo $i; ?>][quantity]" placeholder="1" min="1">
                            <input type="number" name="line_items[<?php echo $i; ?>][unit_price]" placeholder="0.00" step="0.01" min="0">
                            <input type="text" readonly style="background-color: #f0f0f0;">
                        </div>
                    <?php endfor; ?>
                </div>
                
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button type="submit" class="btn">Create Invoice</button>
                    <a href="billing.php" class="btn" style="background-color: #999;">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Edit Invoice Form -->
        <?php if ($action === 'edit' && $edit_invoice): ?>
        <div class="form-section">
            <h2>Edit Invoice - <?php echo escape_output($edit_invoice['invoice_number']); ?></h2>
            <form method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" value="<?php echo $invoice_id; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="draft" <?php echo $edit_invoice['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
                            <option value="sent" <?php echo $edit_invoice['status'] === 'sent' ? 'selected' : ''; ?>>Sent</option>
                            <option value="paid" <?php echo $edit_invoice['status'] === 'paid' ? 'selected' : ''; ?>>Paid</option>
                            <option value="overdue" <?php echo $edit_invoice['status'] === 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Due Date</label>
                        <input type="date" name="due_date" value="<?php echo $edit_invoice['due_date']; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description"><?php echo escape_output($edit_invoice['description']); ?></textarea>
                </div>
                
                <h3 style="margin-top: 20px; margin-bottom: 15px;">Line Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($invoice_items as $item): ?>
                            <tr>
                                <td><?php echo escape_output($item['description']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>BHD <?php echo number_format($item['unit_price'], 2); ?></td>
                                <td>BHD <?php echo number_format($item['total'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <h3 style="margin-top: 20px; margin-bottom: 15px;">Amount</h3>
                <p style="font-size: 18px; font-weight: bold; color: #667eea;">
                    Total: BHD <?php echo number_format($edit_invoice['amount'], 2); ?>
                </p>
                
                <?php if (!empty($invoice_payments)): ?>
                    <h3 style="margin-top: 20px; margin-bottom: 15px;">Payments</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Method</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_paid = 0;
                            foreach ($invoice_payments as $payment): 
                                $total_paid += $payment['amount_paid'];
                            ?>
                                <tr>
                                    <td>BHD <?php echo number_format($payment['amount_paid'], 2); ?></td>
                                    <td><?php echo $payment['payment_date']; ?></td>
                                    <td><?php echo escape_output($payment['payment_method'] ?? 'N/A'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p style="margin-top: 10px; font-size: 16px;">
                        <strong>Total Paid:</strong> BHD <?php echo number_format($total_paid, 2); ?>
                        | <strong>Remaining:</strong> BHD <?php echo number_format($edit_invoice['amount'] - $total_paid, 2); ?>
                    </p>
                <?php endif; ?>
                
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button type="submit" class="btn">Update Invoice</button>
                    <a href="billing.php?action=payment&id=<?php echo $invoice_id; ?>" class="btn" style="background-color: #10b981;">+ Record Payment</a>
                    <a href="billing.php" class="btn" style="background-color: #999;">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Record Payment Form -->
        <?php if ($action === 'payment' && $invoice_id): ?>
        <div class="form-section">
            <h2>Record Payment</h2>
            <form method="POST">
                <input type="hidden" name="action" value="payment">
                <input type="hidden" name="id" value="<?php echo $invoice_id; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Amount Paid *</label>
                        <input type="number" name="amount_paid" placeholder="0.00" step="0.01" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Date</label>
                        <input type="date" name="payment_date" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="payment_method">
                            <option value="">Select method...</option>
                            <option value="Cash">Cash</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Credit Card">Credit Card</option>
                            <option value="Cheque">Cheque</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button type="submit" class="btn">Record Payment</button>
                    <a href="billing.php" class="btn" style="background-color: #999;">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Invoices List -->
        <div class="form-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>All Invoices</h2>
                <a href="billing.php?action=add" class="btn">+ New Invoice</a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Member</th>
                        <th>Amount</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($invoices as $invoice): ?>
                        <tr>
                            <td><strong><?php echo escape_output($invoice['invoice_number']); ?></strong></td>
                            <td><?php echo escape_output($invoice['first_name'] . ' ' . $invoice['last_name']); ?></td>
                            <td>BHD <?php echo number_format($invoice['amount'], 2); ?></td>
                            <td><?php echo date('M d, Y', strtotime($invoice['issue_date'])); ?></td>
                            <td><?php echo $invoice['due_date'] ? date('M d, Y', strtotime($invoice['due_date'])) : '-'; ?></td>
                            <td>
                                <span class="badge <?php echo $invoice['status']; ?>">
                                    <?php echo escape_output(ucfirst($invoice['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 5px;">
                                    <a href="billing.php?action=edit&id=<?php echo $invoice['id']; ?>" class="btn" style="padding: 5px 10px; font-size: 12px;">View</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this invoice?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $invoice['id']; ?>">
                                        <button type="submit" class="btn btn-delete" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
