# IndoGulf Yoga Hub - Deployment Checklist

Use this checklist to deploy your platform on Hostinger smoothly.

## Pre-Deployment (Before Upload)

- [ ] Download all files from the platform
- [ ] Create a folder called `yoga-hub` (or your preference)
- [ ] Place all .php and .sql files in this folder
- [ ] Review `config.php` - you'll edit this soon

## Hostinger Setup

### Database Creation
- [ ] Login to Hostinger cPanel
- [ ] Go to "MySQL Databases"
- [ ] Create new database (name: `indogulf_hub` or similar)
- [ ] Create database user with strong password
- [ ] Write down the credentials:
  - Database Name: ________________
  - Database User: ________________
  - Database Password: ________________

### File Upload
- [ ] Login to Hostinger File Manager or FTP
- [ ] Navigate to `public_html` folder
- [ ] Create subfolder (e.g., `yoga-hub`)
- [ ] Upload all .php files to this folder
- [ ] Upload all other files (.md files are optional)

### Database Import
- [ ] Open phpMyAdmin in Hostinger cPanel
- [ ] Select your new database
- [ ] Click "SQL" tab
- [ ] Copy entire content from `database.sql`
- [ ] Paste into phpMyAdmin SQL editor
- [ ] Click "Go" to execute
- [ ] Verify tables created (check "Structure" tab)

## Configuration

### Update config.php
- [ ] Edit `config.php` with your editor
- [ ] Update DB_HOST: `localhost`
- [ ] Update DB_USER: (from database creation)
- [ ] Update DB_PASS: (from database creation)
- [ ] Update DB_NAME: (from database creation)
- [ ] Update SITE_URL: `https://yourdomain.com`
- [ ] Save the file
- [ ] Re-upload to Hostinger

### Verify File Permissions
- [ ] Create `logs` folder in your yoga-hub directory
- [ ] Set permissions to 755 or 777
- [ ] All .php files should be 644

## First Access

- [ ] Open browser: `https://yourdomain.com/yoga-hub/login.php`
- [ ] Login with default credentials:
  - Username: `admin`
  - Password: `admin123`
- [ ] ✅ You should see the dashboard

## Post-Login Setup

- [ ] Change admin password immediately (create new admin user)
- [ ] Add your company info in dashboard
- [ ] Create sample classes (3-4 test classes)
- [ ] Add sample members (2-3 test members)
- [ ] Test attendance check-in
- [ ] Test invoice creation
- [ ] Test all basic functions

## Security Hardening

- [ ] Delete default admin user after creating new one
- [ ] Change all default passwords
- [ ] Enable HTTPS (Hostinger provides free SSL)
- [ ] Set file permissions properly (644 for files, 755 for folders)
- [ ] Create backups of database (via phpMyAdmin)
- [ ] Download config.php backup to safe location

## Testing

### Test Each Module
- [ ] Members: Add → Edit → Delete member
- [ ] Classes: Add → Edit → Delete class
- [ ] Attendance: Check-in member to class
- [ ] Billing: Create invoice → Add line item → Record payment
- [ ] Dashboard: Verify stats update correctly

### Test Data Entry
- [ ] Test member custom fields
- [ ] Test phone number format
- [ ] Test date pickers
- [ ] Test dropdown selections
- [ ] Test form validation

## Backup Setup

- [ ] Schedule weekly backups via Hostinger
- [ ] Export database to file weekly
- [ ] Store backup files safely
- [ ] Document backup location and process

## Go Live Checklist

- [ ] All modules tested and working
- [ ] All passwords changed from defaults
- [ ] SSL/HTTPS enabled
- [ ] Admin password secure and noted
- [ ] Database backed up
- [ ] Files backed up
- [ ] Users trained on how to use platform
- [ ] Documented any custom settings

## Ongoing Maintenance

**Weekly:**
- [ ] Backup database
- [ ] Check if any errors in logs

**Monthly:**
- [ ] Review and delete old records if needed
- [ ] Check Hostinger account status
- [ ] Verify all features still working

**Quarterly:**
- [ ] Full database backup to external storage
- [ ] Security audit
- [ ] Consider software updates

---

## Important Files & Access

| Item | Location | Username | Password |
|------|----------|----------|----------|
| Platform | https://yourdomain.com/yoga-hub/login.php | admin | *(Change immediately)* |
| Database | cPanel > phpMyAdmin | *(From creation)* | *(From creation)* |
| File Manager | cPanel > File Manager | *(Hostinger account)* | *(Hostinger password)* |
| FTP/SFTP | ftp.yourdomain.com | *(Hostinger account)* | *(Hostinger password)* |

---

## Emergency Contacts

If something goes wrong:

1. **Database connection issues?**
   - Check config.php credentials
   - Verify database exists in phpMyAdmin
   - Contact Hostinger support

2. **Seeing blank page?**
   - Check browser console (F12)
   - Check Hostinger error logs
   - Verify all .php files uploaded

3. **Login not working?**
   - Clear browser cache
   - Verify database.sql imported correctly
   - Check admin_users table in phpMyAdmin

4. **Slow website?**
   - Check Hostinger resource usage
   - Consider deleting old records
   - Contact Hostinger support

---

## Success! 🎉

You've successfully deployed IndoGulf Yoga Hub!

**Next steps:**
1. Start adding your real members
2. Create your actual classes
3. Begin tracking attendance
4. Generate invoices
5. Monitor and optimize

**Remember:** Regular backups are your lifeline. Never skip them!

For detailed instructions, see `README.md`
