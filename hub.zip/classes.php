<?php
require_once 'config.php';
check_admin_login();

$action = $_GET['action'] ?? '';
$class_id = $_GET['id'] ?? '';
$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $class_name = $_POST['class_name'] ?? '';
        $description = $_POST['description'] ?? '';
        $instructor = $_POST['instructor'] ?? '';
        $schedule_day = $_POST['schedule_day'] ?? '';
        $schedule_time = $_POST['schedule_time'] ?? '';
        $max_capacity = $_POST['max_capacity'] ?? 20;
        $class_type = $_POST['class_type'] ?? '';
        $location = $_POST['location'] ?? '';
        $status = $_POST['status'] ?? 'active';
        
        if ($class_name) {
            $stmt = $conn->prepare("
                INSERT INTO classes (class_name, description, instructor, schedule_day, schedule_time, max_capacity, class_type, location, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssississs", $class_name, $description, $instructor, $schedule_day, $schedule_time, $max_capacity, $class_type, $location, $status);
            
            if ($stmt->execute()) {
                $message = "Class added successfully!";
                $action = '';
            }
        }
    } elseif ($action === 'edit' && $class_id) {
        $class_name = $_POST['class_name'] ?? '';
        $description = $_POST['description'] ?? '';
        $instructor = $_POST['instructor'] ?? '';
        $schedule_day = $_POST['schedule_day'] ?? '';
        $schedule_time = $_POST['schedule_time'] ?? '';
        $max_capacity = $_POST['max_capacity'] ?? 20;
        $class_type = $_POST['class_type'] ?? '';
        $location = $_POST['location'] ?? '';
        $status = $_POST['status'] ?? 'active';
        
        $stmt = $conn->prepare("
            UPDATE classes 
            SET class_name=?, description=?, instructor=?, schedule_day=?, schedule_time=?, max_capacity=?, class_type=?, location=?, status=?
            WHERE id=?
        ");
        $stmt->bind_param("ssississi", $class_name, $description, $instructor, $schedule_day, $schedule_time, $max_capacity, $class_type, $location, $status, $class_id);
        
        if ($stmt->execute()) {
            $message = "Class updated successfully!";
            $action = '';
        }
    } elseif ($action === 'delete' && $class_id) {
        $stmt = $conn->prepare("DELETE FROM classes WHERE id=?");
        $stmt->bind_param("i", $class_id);
        
        if ($stmt->execute()) {
            $message = "Class deleted successfully!";
            header('Location: classes.php');
            exit();
        }
    }
}

// Get class for editing
$edit_class = null;
if ($action === 'edit' && $class_id) {
    $result = $conn->query("SELECT * FROM classes WHERE id=$class_id");
    $edit_class = $result->fetch_assoc();
}

// Get all classes
$classes = $conn->query("SELECT * FROM classes ORDER BY schedule_day, schedule_time")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classes - IndoGulf Yoga Hub</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background-color: #764ba2;
        }
        
        .btn-delete {
            background-color: #ef4444;
        }
        
        .btn-delete:hover {
            background-color: #dc2626;
        }
        
        .message {
            background-color: #d1fae5;
            color: #065f46;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #a7f3d0;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section h2 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="time"],
        input[type="number"],
        select,
        textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
        }
        
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        
        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.1);
        }
        
        .form-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        th {
            background-color: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            background-color: #d1fae5;
            color: #065f46;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Classes Management</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <!-- Add/Edit Class Form -->
        <?php if ($action === 'add' || $action === 'edit'): ?>
        <div class="form-section">
            <h2><?php echo $action === 'add' ? 'Add New Class' : 'Edit Class'; ?></h2>
            <form method="POST">
                <input type="hidden" name="action" value="<?php echo $action; ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Class Name *</label>
                        <input type="text" name="class_name" value="<?php echo $edit_class['class_name'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Instructor</label>
                        <input type="text" name="instructor" value="<?php echo $edit_class['instructor'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Class Type</label>
                        <select name="class_type">
                            <option value="">Select Type</option>
                            <option value="Yoga" <?php echo ($edit_class['class_type'] ?? '') === 'Yoga' ? 'selected' : ''; ?>>Yoga</option>
                            <option value="Aquatics" <?php echo ($edit_class['class_type'] ?? '') === 'Aquatics' ? 'selected' : ''; ?>>Aquatics</option>
                            <option value="Fitness" <?php echo ($edit_class['class_type'] ?? '') === 'Fitness' ? 'selected' : ''; ?>>Fitness</option>
                            <option value="Pilates" <?php echo ($edit_class['class_type'] ?? '') === 'Pilates' ? 'selected' : ''; ?>>Pilates</option>
                            <option value="Dance" <?php echo ($edit_class['class_type'] ?? '') === 'Dance' ? 'selected' : ''; ?>>Dance</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="location" value="<?php echo $edit_class['location'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Schedule Day</label>
                        <select name="schedule_day">
                            <option value="">Select Day</option>
                            <option value="Monday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Monday' ? 'selected' : ''; ?>>Monday</option>
                            <option value="Tuesday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Tuesday' ? 'selected' : ''; ?>>Tuesday</option>
                            <option value="Wednesday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Wednesday' ? 'selected' : ''; ?>>Wednesday</option>
                            <option value="Thursday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Thursday' ? 'selected' : ''; ?>>Thursday</option>
                            <option value="Friday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Friday' ? 'selected' : ''; ?>>Friday</option>
                            <option value="Saturday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Saturday' ? 'selected' : ''; ?>>Saturday</option>
                            <option value="Sunday" <?php echo ($edit_class['schedule_day'] ?? '') === 'Sunday' ? 'selected' : ''; ?>>Sunday</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Time</label>
                        <input type="time" name="schedule_time" value="<?php echo $edit_class['schedule_time'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Max Capacity</label>
                        <input type="number" name="max_capacity" value="<?php echo $edit_class['max_capacity'] ?? 20; ?>" min="1">
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="active" <?php echo ($edit_class['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo ($edit_class['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description"><?php echo $edit_class['description'] ?? ''; ?></textarea>
                </div>
                
                <div class="form-buttons">
                    <button type="submit" class="btn">Save Class</button>
                    <a href="classes.php" class="btn" style="background-color: #999;">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Classes List -->
        <div class="form-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>All Classes</h2>
                <a href="classes.php?action=add" class="btn">+ Add Class</a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Class Name</th>
                        <th>Type</th>
                        <th>Instructor</th>
                        <th>Schedule</th>
                        <th>Location</th>
                        <th>Capacity</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($classes as $class): ?>
                        <tr>
                            <td><?php echo escape_output($class['class_name']); ?></td>
                            <td><?php echo escape_output($class['class_type'] ?? 'N/A'); ?></td>
                            <td><?php echo escape_output($class['instructor'] ?? 'N/A'); ?></td>
                            <td><?php echo escape_output($class['schedule_day'] . ' ' . $class['schedule_time']); ?></td>
                            <td><?php echo escape_output($class['location'] ?? 'N/A'); ?></td>
                            <td><?php echo $class['max_capacity']; ?></td>
                            <td>
                                <span class="badge"><?php echo escape_output(ucfirst($class['status'])); ?></span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="classes.php?action=edit&id=<?php echo $class['id']; ?>" class="btn" style="padding: 5px 10px; font-size: 12px;">Edit</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this class?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $class['id']; ?>">
                                        <button type="submit" class="btn btn-delete" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
