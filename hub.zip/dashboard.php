<?php
require_once 'config.php';
check_admin_login();

// Get statistics
$total_members = $conn->query("SELECT COUNT(*) as count FROM members")->fetch_assoc()['count'];
$active_members = $conn->query("SELECT COUNT(*) as count FROM members WHERE status='active'")->fetch_assoc()['count'];
$total_classes = $conn->query("SELECT COUNT(*) as count FROM classes WHERE status='active'")->fetch_assoc()['count'];
$total_invoices = $conn->query("SELECT COUNT(*) as count FROM invoices")->fetch_assoc()['count'];
$pending_invoices = $conn->query("SELECT COUNT(*) as count FROM invoices WHERE status='sent' OR status='overdue'")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(amount) as total FROM invoices WHERE status='paid'")->fetch_assoc()['total'] ?? 0;

// Recent attendance
$recent_attendance = $conn->query("
    SELECT a.*, m.first_name, m.last_name, c.class_name 
    FROM attendance a 
    JOIN members m ON a.member_id = m.id 
    JOIN classes c ON a.class_id = c.id 
    ORDER BY a.created_at DESC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

// Recent members
$recent_members = $conn->query("
    SELECT * FROM members 
    ORDER BY created_at DESC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IndoGulf Yoga Hub</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .navbar h1 {
            font-size: 24px;
        }
        
        .navbar a {
            color: white;
            text-decoration: none;
            background: rgba(255,255,255,0.2);
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .navbar a:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 5px solid #667eea;
        }
        
        .stat-card.revenue {
            border-left-color: #10b981;
        }
        
        .stat-card.pending {
            border-left-color: #f59e0b;
        }
        
        .stat-card.classes {
            border-left-color: #3b82f6;
        }
        
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 14px;
        }
        
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .menu-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
        }
        
        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        
        .menu-card a {
            text-decoration: none;
            color: inherit;
            display: block;
        }
        
        .menu-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }
        
        .menu-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .menu-desc {
            color: #999;
            font-size: 12px;
            margin-top: 8px;
        }
        
        .section-title {
            font-size: 20px;
            color: #333;
            margin: 30px 0 20px 0;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        th {
            background-color: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge.active {
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .badge.pending {
            background-color: #fef3c7;
            color: #92400e;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>IndoGulf Yoga Hub</h1>
        <div>
            <span>Welcome, <?php echo escape_output($_SESSION['admin_username']); ?></span>
            &nbsp; | &nbsp;
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_members; ?></div>
                <div class="stat-label">Total Members</div>
                <div class="stat-label">Active: <?php echo $active_members; ?></div>
            </div>
            
            <div class="stat-card classes">
                <div class="stat-number"><?php echo $total_classes; ?></div>
                <div class="stat-label">Active Classes</div>
            </div>
            
            <div class="stat-card pending">
                <div class="stat-number"><?php echo $pending_invoices; ?></div>
                <div class="stat-label">Pending Invoices</div>
                <div class="stat-label">Total: <?php echo $total_invoices; ?></div>
            </div>
            
            <div class="stat-card revenue">
                <div class="stat-number">BHD <?php echo number_format($total_revenue, 2); ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
        </div>
        
        <!-- Main Menu -->
        <div class="section-title">Quick Actions</div>
        <div class="menu-grid">
            <div class="menu-card">
                <a href="members.php">
                    <div class="menu-icon">👥</div>
                    <div class="menu-title">Members</div>
                    <div class="menu-desc">Manage customer profiles</div>
                </a>
            </div>
            
            <div class="menu-card">
                <a href="classes.php">
                    <div class="menu-icon">📅</div>
                    <div class="menu-title">Classes</div>
                    <div class="menu-desc">Schedule & manage classes</div>
                </a>
            </div>
            
            <div class="menu-card">
                <a href="attendance.php">
                    <div class="menu-icon">✅</div>
                    <div class="menu-title">Attendance</div>
                    <div class="menu-desc">Track member attendance</div>
                </a>
            </div>
            
            <div class="menu-card">
                <a href="billing.php">
                    <div class="menu-icon">💰</div>
                    <div class="menu-title">Billing</div>
                    <div class="menu-desc">Invoices & payments</div>
                </a>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="section-title">Recent Attendance</div>
        <table>
            <thead>
                <tr>
                    <th>Member</th>
                    <th>Class</th>
                    <th>Check-in</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($recent_attendance)): ?>
                    <?php foreach ($recent_attendance as $attendance): ?>
                        <tr>
                            <td><?php echo escape_output($attendance['first_name'] . ' ' . $attendance['last_name']); ?></td>
                            <td><?php echo escape_output($attendance['class_name']); ?></td>
                            <td><?php echo date('M d, H:i', strtotime($attendance['check_in_time'])); ?></td>
                            <td>
                                <span class="badge active"><?php echo escape_output($attendance['status']); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4" style="text-align: center; color: #999;">No attendance records yet</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Recent Members -->
        <div class="section-title">Recent Members</div>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Membership Type</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($recent_members)): ?>
                    <?php foreach ($recent_members as $member): ?>
                        <tr>
                            <td><?php echo escape_output($member['first_name'] . ' ' . $member['last_name']); ?></td>
                            <td><?php echo escape_output($member['email'] ?? 'N/A'); ?></td>
                            <td><?php echo escape_output($member['phone'] ?? 'N/A'); ?></td>
                            <td><?php echo escape_output($member['membership_type'] ?? 'N/A'); ?></td>
                            <td>
                                <span class="badge <?php echo $member['status'] === 'active' ? 'active' : 'pending'; ?>">
                                    <?php echo escape_output(ucfirst($member['status'])); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; color: #999;">No members yet</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
