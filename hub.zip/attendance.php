<?php
require_once 'config.php';
check_admin_login();

$message = '';
$filter_date = $_GET['date'] ?? date('Y-m-d');
$filter_class = $_GET['class'] ?? '';

// Handle attendance recording
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'checkin') {
        $member_id = $_POST['member_id'] ?? '';
        $class_id = $_POST['class_id'] ?? '';
        $recorded_date = $_POST['recorded_date'] ?? date('Y-m-d');
        
        if ($member_id && $class_id) {
            // Check if already checked in today for this class
            $existing = $conn->query("
                SELECT id FROM attendance 
                WHERE member_id=$member_id AND class_id=$class_id AND recorded_date='$recorded_date' AND status='present'
            ");
            
            if ($existing->num_rows === 0) {
                $check_in_time = date('Y-m-d H:i:s');
                $status = 'present';
                $stmt = $conn->prepare("
                    INSERT INTO attendance (member_id, class_id, check_in_time, status, recorded_date)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("iisss", $member_id, $class_id, $check_in_time, $status, $recorded_date);
                
                if ($stmt->execute()) {
                    $message = "Member checked in successfully!";
                }
            } else {
                $message = "Member already checked in for this class today";
            }
        }
    } elseif ($action === 'delete') {
        $attendance_id = $_POST['id'] ?? '';
        if ($attendance_id) {
            $stmt = $conn->prepare("DELETE FROM attendance WHERE id=?");
            $stmt->bind_param("i", $attendance_id);
            if ($stmt->execute()) {
                $message = "Attendance record deleted";
            }
        }
    }
}

// Get filter options
$classes = $conn->query("SELECT * FROM classes WHERE status='active' ORDER BY class_name")->fetch_all(MYSQLI_ASSOC);

// Get attendance records
$query = "
    SELECT a.*, m.first_name, m.last_name, c.class_name 
    FROM attendance a 
    JOIN members m ON a.member_id = m.id 
    JOIN classes c ON a.class_id = c.id 
    WHERE a.recorded_date = '$filter_date'
";

if ($filter_class) {
    $query .= " AND a.class_id = $filter_class";
}

$query .= " ORDER BY a.check_in_time DESC";
$attendance_records = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

// Get members for quick check-in
$members = $conn->query("SELECT id, first_name, last_name FROM members WHERE status='active' ORDER BY first_name")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - IndoGulf Yoga Hub</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }
        
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background-color: #764ba2;
        }
        
        .btn-delete {
            background-color: #ef4444;
        }
        
        .btn-delete:hover {
            background-color: #dc2626;
        }
        
        .message {
            background-color: #d1fae5;
            color: #065f46;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #a7f3d0;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .form-section h2 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="date"],
        select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: inherit;
        }
        
        input:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.1);
        }
        
        .form-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        th {
            background-color: #667eea;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            background-color: #d1fae5;
            color: #065f46;
        }
        
        .badge.absent {
            background-color: #fee2e2;
            color: #991b1b;
        }
        
        .badge.late {
            background-color: #fef3c7;
            color: #92400e;
        }
        
        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Attendance Tracking</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <!-- Quick Check-in Form -->
        <div class="form-section">
            <h2>Quick Check-in</h2>
            <form method="POST">
                <input type="hidden" name="action" value="checkin">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Select Member *</label>
                        <select name="member_id" required>
                            <option value="">Choose a member...</option>
                            <?php foreach ($members as $member): ?>
                                <option value="<?php echo $member['id']; ?>">
                                    <?php echo escape_output($member['first_name'] . ' ' . $member['last_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Select Class *</label>
                        <select name="class_id" required>
                            <option value="">Choose a class...</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['id']; ?>">
                                    <?php echo escape_output($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" name="recorded_date" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                
                <div class="form-buttons">
                    <button type="submit" class="btn">✓ Check In</button>
                </div>
            </form>
        </div>
        
        <!-- Filter Section -->
        <div class="form-section">
            <h2>Attendance Records</h2>
            <div class="filter-section">
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" value="<?php echo $filter_date; ?>" onchange="window.location.href='attendance.php?date=' + this.value + '&class=<?php echo $filter_class; ?>'">
                </div>
                
                <div class="form-group">
                    <label>Class</label>
                    <select onchange="window.location.href='attendance.php?date=<?php echo $filter_date; ?>&class=' + this.value">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>" <?php echo $filter_class == $class['id'] ? 'selected' : ''; ?>>
                                <?php echo escape_output($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <!-- Attendance Table -->
            <table>
                <thead>
                    <tr>
                        <th>Member Name</th>
                        <th>Class</th>
                        <th>Check-in Time</th>
                        <th>Check-out Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($attendance_records)): ?>
                        <?php foreach ($attendance_records as $record): ?>
                            <tr>
                                <td><?php echo escape_output($record['first_name'] . ' ' . $record['last_name']); ?></td>
                                <td><?php echo escape_output($record['class_name']); ?></td>
                                <td><?php echo $record['check_in_time'] ? date('H:i', strtotime($record['check_in_time'])) : '-'; ?></td>
                                <td><?php echo $record['check_out_time'] ? date('H:i', strtotime($record['check_out_time'])) : '-'; ?></td>
                                <td>
                                    <span class="badge <?php echo $record['status']; ?>">
                                        <?php echo escape_output(ucfirst($record['status'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this record?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $record['id']; ?>">
                                        <button type="submit" class="btn btn-delete" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align: center; color: #999;">No attendance records for this date/class</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
